const videoElement = document.getElementById("video");
const canvasElement = document.getElementById("output");
const canvasCtx = canvasElement.getContext("2d");

const gestureText = document.getElementById("gesture");
const counterText = document.getElementById("counter");

canvasElement.width = 640;
canvasElement.height = 480;

// 🔊 Load sound
const peaceSound = new Audio("sound/mixkit-alarm-clock-beep-988.wav");
peaceSound.volume = 0.7;

// Gesture counters
let gestureCounts = {
  "Thumbs Up": 0,
  "Peace Sign": 0,
  "Open Palm": 0,
  "Fist": 0,
  "Rock Sign": 0,
  "OK Sign": 0
};

let lastGesture = "None";

// Initialize MediaPipe Hands
const hands = new Hands({
  locateFile: (file) =>
    `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
});

hands.setOptions({
  maxNumHands: 1,
  modelComplexity: 1,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7
});

// 🧠 Gesture recognition
function recognizeGesture(landmarks) {
  const thumbUp = landmarks[4].y < landmarks[3].y;
  const indexUp = landmarks[8].y < landmarks[6].y;
  const middleUp = landmarks[12].y < landmarks[10].y;
  const ringUp = landmarks[16].y < landmarks[14].y;
  const pinkyUp = landmarks[20].y < landmarks[18].y;

  // 👍 Thumbs Up
  if (thumbUp && !indexUp && !middleUp && !ringUp && !pinkyUp)
    return "Thumbs Up";

  // ✌️ Peace Sign
  if (indexUp && middleUp && !ringUp && !pinkyUp)
    return "Peace Sign";

  // 🤟 Rock Sign / I Love You
  if (thumbUp && indexUp && !middleUp && !ringUp && pinkyUp)
    return "Rock Sign";

  // 👌 OK Sign (thumb touches index)
  const thumbIndexDistance = Math.hypot(
    landmarks[4].x - landmarks[8].x,
    landmarks[4].y - landmarks[8].y
  );
  if (thumbIndexDistance < 0.05 && middleUp && ringUp && pinkyUp)
    return "OK Sign";

  // ✋ Open Palm
  if (thumbUp && indexUp && middleUp && ringUp && pinkyUp)
    return "Open Palm";

  // ✊ Fist
  if (!thumbUp && !indexUp && !middleUp && !ringUp && !pinkyUp)
    return "Fist";

  return "None";
}

// 🎯 Action trigger
function triggerAction(gesture) {
  switch (gesture) {
    case "Thumbs Up":
      document.body.style.backgroundColor = "#2ecc71";
      break;

    case "Peace Sign":
      document.body.style.backgroundColor = "#3498db";
      peaceSound.currentTime = 0;
      peaceSound.play();
      break;

    case "Open Palm":
      document.body.style.backgroundColor = "#f1c40f";
      break;

    case "Fist":
      document.body.style.backgroundColor = "#e74c3c";
      break;

    case "Rock Sign":
      document.body.style.backgroundColor = "#9b59b6";
      break;

    case "OK Sign":
      document.body.style.backgroundColor = "#e67e22";
      break;

    default:
      document.body.style.backgroundColor = "#111";
  }
}

// MediaPipe results callback
hands.onResults((results) => {
  canvasCtx.save();
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

  canvasCtx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);

  if (results.multiHandLandmarks) {
    for (const landmarks of results.multiHandLandmarks) {

      drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, {
        color: "#00FF00",
        lineWidth: 2
      });

      drawLandmarks(canvasCtx, landmarks, {
        color: "#FF0000",
        lineWidth: 1
      });

      const gesture = recognizeGesture(landmarks);
      gestureText.innerText = `Gesture: ${gesture}`;

      if (gesture !== "None" && gesture !== lastGesture) {
        gestureCounts[gesture]++;
        counterText.innerText =
          `👍 ${gestureCounts["Thumbs Up"]} | ✌️ ${gestureCounts["Peace Sign"]} | ✋ ${gestureCounts["Open Palm"]} | ✊ ${gestureCounts["Fist"]} | 🤟 ${gestureCounts["Rock Sign"]} | 👌 ${gestureCounts["OK Sign"]}`;

        triggerAction(gesture);
        lastGesture = gesture;
      }

      if (gesture === "None") lastGesture = "None";
    }
  }

  canvasCtx.restore();
});

// Camera setup
const camera = new Camera(videoElement, {
  onFrame: async () => {
    await hands.send({ image: videoElement });
  },
  width: 640,
  height: 480
});

camera.start();
